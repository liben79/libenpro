<!DOCTYPE html>
<html>
<head>
    <title>profile</title>

</head>
<link rel="stylesheet" type="text/css" href="pro.css">
<style type="text/css">
    .begin{
  
    text-align: center;
    margin-top: 10px;
    font-size: 30px;
    background-color: #789;
    color:black;
    padding: 10px;

   
}
.exp{
      text-align: center;
 
    font-size: 30px;
    background-color: #789;
    color: black;
    padding: 10px;

}
.btn{
    text-align: center;
    font-size: 30px;
    background-color: blue;
    color: black&nbsp;&nbsp;&nbsp;&nbsp;;
    border-radius: 50px;
    border:10px red solid ;
    margin-top: 10px;

}
.btn:hover,a:hover{
    background-color: brown;
    color: black;
    margin-bottom: 5px;
}
.v1{
    margin-left: 400px
    height:200px;
    color:solid green;
}
input{
    font-size: 20px;
  margin-right: 100px;


}
input:hover, a:hover{
    border-radius: 50px;
    border|:4px;
    border-bottom-color: blue;
}
h1{
    color: black;
}

</style>
<body>

    
      
            <fieldset>   
               
                <div class="begin">
                       <h1>Profile Settings</h1>  

              <img class="rounded-circle mt-5" src="http://localhost/diabetes/doctor1.jpg"><br>
              
                
                <label class="labels">Name&nbsp;&nbsp;&nbsp;&nbsp;</label><input type="text" class="form-control" placeholder="first name" value=""><br>
                        <label class="labels">Surname&nbsp;&nbsp;&nbsp;&nbsp;</label><input type="text" class="form-control" value="" placeholder="surname"><br>
                        <label class="labels">PhoneNumber&nbsp;&nbsp;&nbsp;&nbsp;</label><input type="text" class="form-control" placeholder="enter phone number" value=""><br>
                        <label class="labels">Address&nbsp;&nbsp;&nbsp;&nbsp;</label><input type="text" class="form-control" placeholder="enter address" value=""><br>
                        <label class="labels">Email ID&nbsp;&nbsp;&nbsp;&nbsp;</label><input type="text" class="form-control" placeholder="enter email id" value=""><br>
                        <label class="labels">Education&nbsp;&nbsp;&nbsp;&nbsp;</label><input type="text" class="form-control" placeholder="education" value=""><br>
               <label class="labels">Country&nbsp;&nbsp;&nbsp;&nbsp;</label><input type="text" class="form-control" placeholder="country" value=""><br>
                   <label class="labels">State/Region&nbsp;&nbsp;&nbsp;&nbsp;</label><input type="text" class="form-control" value="" placeholder="state"><br>
         
          

                  </div>
              <div class="v1"></div>
                   
     
              
    
            <div class="exp">
           <span><b><u>Edit Experience</u></b></span><span class="border px-3 p-1 add-experience"><br>
              <label class="labels">Experience in Designing&nbsp;&nbsp;&nbsp;&nbsp;</label><input type="text" class="form-control" placeholder="experience" value=""><br><br>
              <label class="labels">Additional Details&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<textarea style="border: 10px solid pink" rows="5" cols="60" placeholder="write additional Information here"></textarea><br>
       
              <button class="btn " type="button">Save Profile&nbsp;&nbsp;&nbsp;&nbsp;</button><br>
                 </div>
       </fieldset>
     
</body>
</html>