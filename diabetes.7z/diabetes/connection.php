<?php
$conn=mysqli_connect("localhost","root","","diabetes");
if(!$conn){
	echo 'connection not successfully';
}

?>