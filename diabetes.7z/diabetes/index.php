<!DOCTYPE html>
<html>
<head>
	<title>Diabetes prediction system</title>
</head>
<style type="text/css">
	body{
		background-image: url(doctor3.jpg);
		 background-repeat: no-repeat;
  background-size: 700px 700px;



	}
	form{
		background-color:#678999;
		border: 20px;
		border-color:blue;
		font-size: 30px;
		padding: 10px;
		border-radius: 3px;
		width: 800px;
		margin: 0 auto;
		color: white;
		margin-top: 50px;
		text-align: center;
		margin-right: 30px;
	}
	.sign{
		margin-left: 600px;
		background-color: white;
		margin-right: 30px;
		text-align: center;
	}
	input{
		font-size:20px;

	}

	.submit{
		background-color:gray;
		color: ;
		border-radius: 50px;
		font-size: 40px;
		text-decoration:none;

	}
.submit:hover,a:hover{
		background-color:brown;
		color: white;
		margin-bottom: 20px;
		border-color: blue;
		text-decoration: none;
	}
	
	h1{
		background-color: gray;
		color: white;
		text-align: center;
	}
	fieldset{
		color:white;
	}
h2{ background-color:#383838;
	text-align: center;
		color: white;
		margin-bottom: 3px;

	}
</style>
<body>
	<h1>Home page for diabetes diagoses system </h1>

<div class="f2">
<form method="post" action="">
	<fieldset>
		<p>
			<h3>The following features have been provided to help us predict whether a person is diabetic or not:</h3>
(1). Pregnancies:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
(2).Glucose: <br>
(3).BloodPressure:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
(4).SkinThickness: <br>
(5).Insulin:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
(6).BMI: <br>
(7).Diabetes PedigreeFunction: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
(8).Age:<br>
(9).Outcome: <br>
		</p>
	</fieldset>
</form>
</div>
<form>
	
<div class="submit">
	<a href="http://localhost/diabetes/login.php">Go to login page now</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</div>
</form>
<h2> Welcome To Our &nbsp;&nbsp;System.</h2>
</body>
</html>